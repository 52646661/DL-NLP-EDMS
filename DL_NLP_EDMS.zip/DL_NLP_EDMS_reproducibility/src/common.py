from pathlib import Path
import json
import pandas as pd
from PIL import Image

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}

def discover_images(data_dir):
    root = Path(data_dir)
    if not root.exists():
        raise FileNotFoundError(f"Dataset directory not found: {root}")
    rows = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            try:
                with Image.open(p) as im:
                    im.verify()
                # Label from the immediate parent directory; adapt if your dataset
                # uses a different label convention.
                rows.append({"path": str(p.resolve()), "label": p.parent.name})
            except Exception as exc:
                print(f"Skipping unreadable image {p}: {exc}")
    if not rows:
        raise RuntimeError(
            "No images found. Ensure data is extracted and images are in "
            "class-specific folders (class_name/image.ext)."
        )
    df = pd.DataFrame(rows).drop_duplicates(subset=["path"]).reset_index(drop=True)
    return df

def load_split(split_dir, split):
    p = Path(split_dir) / f"{split}.csv"
    if not p.exists():
        raise FileNotFoundError(f"Missing split file: {p}")
    return pd.read_csv(p)

def save_json(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2), encoding="utf-8")
