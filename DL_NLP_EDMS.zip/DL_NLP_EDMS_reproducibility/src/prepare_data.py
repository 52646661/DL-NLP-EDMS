import argparse
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from common import discover_images, save_json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--output-dir", default="artifacts/splits")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--train", type=float, default=0.70)
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.15)
    args = ap.parse_args()

    total = args.train + args.val + args.test
    if abs(total - 1.0) > 1e-8:
        raise ValueError("train + val + test must sum to 1.0")
    df = discover_images(args.data_dir)
    counts = df.label.value_counts()
    # Stratification requires at least two examples per class.
    if (counts < 2).any():
        raise ValueError("Each class needs >=2 images for stratified splitting.")
    train_df, temp_df = train_test_split(
        df, test_size=(1 - args.train), random_state=args.seed,
        stratify=df["label"]
    )
    val_fraction_of_temp = args.val / (args.val + args.test)
    val_df, test_df = train_test_split(
        temp_df, test_size=(1 - val_fraction_of_temp),
        random_state=args.seed, stratify=temp_df["label"]
    )
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    train_df.assign(split="train").to_csv(out / "train.csv", index=False)
    val_df.assign(split="val").to_csv(out / "val.csv", index=False)
    test_df.assign(split="test").to_csv(out / "test.csv", index=False)
    class_names = sorted(df.label.unique().tolist())
    save_json(class_names, out / "class_names.json")
    summary = {
        "dataset_root": str(Path(args.data_dir).resolve()),
        "seed": args.seed,
        "split": {"train": args.train, "val": args.val, "test": args.test},
        "n_images": int(len(df)),
        "n_classes": int(df.label.nunique()),
        "class_counts": {str(k): int(v) for k, v in counts.items()},
        "split_counts": {
            "train": int(len(train_df)), "val": int(len(val_df)),
            "test": int(len(test_df))
        }
    }
    save_json(summary, out / "split_summary.json")
    print(summary)

if __name__ == "__main__":
    main()
