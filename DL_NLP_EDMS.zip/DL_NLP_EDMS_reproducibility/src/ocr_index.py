import argparse, json, re
from pathlib import Path
import pandas as pd
from PIL import Image
import pytesseract
from common import load_split

def tokenize(text):
    return re.findall(r"[a-zA-Z0-9]+", text.lower())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--split-dir", default="artifacts/splits")
    ap.add_argument("--output-dir", default="artifacts/ocr_index")
    ap.add_argument("--max-images", type=int, default=0,
                    help="0 means process all test images")
    args = ap.parse_args()
    df = load_split(args.split_dir, "test")
    if args.max_images:
        df = df.head(args.max_images)
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    jsonl = out / "documents.jsonl"
    with jsonl.open("w", encoding="utf-8") as f:
        for row in df.itertuples():
            try:
                text = pytesseract.image_to_string(Image.open(row.path))
            except Exception as e:
                text = ""
                print(f"OCR failed for {row.path}: {e}")
            record = {
                "path": row.path, "label": row.label,
                "text": text, "tokens": tokenize(text)
            }
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    print(f"Wrote OCR index to {jsonl}")

if __name__ == "__main__":
    main()
