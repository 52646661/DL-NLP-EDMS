"""Minimal keyword retrieval over OCR JSONL documents."""
import argparse, json, re
from pathlib import Path

def tokens(s):
    return set(re.findall(r"[a-zA-Z0-9]+", s.lower()))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index", default="artifacts/ocr_index/documents.jsonl")
    ap.add_argument("--query", required=True)
    ap.add_argument("--top-k", type=int, default=10)
    args = ap.parse_args()
    q = tokens(args.query)
    results = []
    with Path(args.index).open(encoding="utf-8") as f:
        for line in f:
            doc = json.loads(line)
            doc_tokens = set(doc.get("tokens", []))
            score = len(q & doc_tokens) / max(len(q), 1)
            if score:
                results.append((score, doc))
    results.sort(key=lambda x: x[0], reverse=True)
    for score, doc in results[:args.top_k]:
        print(f"{score:.3f}\\t{doc['label']}\\t{doc['path']}")
        print(doc.get("text", "")[:500].replace("\\n", " "))
        print("-" * 60)

if __name__ == "__main__":
    main()
