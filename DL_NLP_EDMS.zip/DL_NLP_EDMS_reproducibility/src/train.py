import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras import layers
from common import load_split, save_json

def make_ds(df, class_to_id, batch, training):
    paths = df.path.astype(str).to_numpy()
    labels = df.label.map(class_to_id).astype("int32").to_numpy()
    ds = tf.data.Dataset.from_tensor_slices((paths, labels))
    def load(path, label):
        raw = tf.io.read_file(path)
        img = tf.image.decode_image(raw, channels=3, expand_animations=False)
        img.set_shape([None, None, 3])
        img = tf.image.resize(img, (224, 224))
        img = tf.cast(img, tf.float32) / 255.0
        return img, label
    ds = ds.map(load, num_parallel_calls=tf.data.AUTOTUNE)
    if training:
        aug = tf.keras.Sequential([
            layers.RandomRotation(0.05),
            layers.RandomTranslation(0.05, 0.05),
            layers.RandomZoom(0.10)
        ])
        ds = ds.map(lambda x, y: (aug(x, training=True), y),
                    num_parallel_calls=tf.data.AUTOTUNE)
        ds = ds.shuffle(min(len(df), 10000), seed=42)
    return ds.batch(batch).prefetch(tf.data.AUTOTUNE)

def build_model(n_classes):
    inputs = layers.Input((224, 224, 3))
    x = inputs
    for filters in [32, 64, 128]:
        x = layers.Conv2D(filters, 3, padding="same", activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.MaxPooling2D()(x)
        x = layers.Dropout(0.20)(x)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(256, activation="relu")(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(n_classes, activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--split-dir", default="artifacts/splits")
    ap.add_argument("--output-dir", default="artifacts/model")
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=0.001)
    args = ap.parse_args()

    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    train_df = load_split(args.split_dir, "train")
    val_df = load_split(args.split_dir, "val")
    names = sorted(pd.concat([train_df, val_df]).label.unique().tolist())
    class_to_id = {name: i for i, name in enumerate(names)}
    save_json(names, out / "class_names.json")

    train_ds = make_ds(train_df, class_to_id, args.batch_size, True)
    val_ds = make_ds(val_df, class_to_id, args.batch_size, False)
    model = build_model(len(names))
    model.optimizer.learning_rate.assign(args.lr)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(
            out / "best_model.keras", monitor="val_loss",
            save_best_only=True, verbose=1
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=5, restore_best_weights=True
        ),
        tf.keras.callbacks.CSVLogger(out / "training_log.csv")
    ]
    history = model.fit(
        train_ds, validation_data=val_ds, epochs=args.epochs,
        callbacks=callbacks
    )
    save_json({k: [float(x) for x in v] for k, v in history.history.items()},
              out / "history.json")
    model.save(out / "final_model.keras")
    print(f"Saved model artifacts to {out}")

if __name__ == "__main__":
    main()
