## DATA AVAILABILITY

The dataset used in this study was obtained from the RVL-CDIP document image
dataset available through Kaggle:
https://www.kaggle.com/datasets/pdavpoojan/the-rvlcdip-dataset-test

The exact Kaggle dataset version/download date and dataset-specific class and
image counts must be recorded by the authors from their experimental records.
The original dataset is subject to its source license and access conditions.

The code and scripts in this repository provide a reproducible implementation
example. The study-specific split files, numerical source data underlying
Figures 4–8, trained model artifacts, and experimental logs must be generated
from the exact study run and deposited alongside this code before claiming that
the repository reproduces the published results. Do not fabricate source data
from plotted bars. Dataset images should not be redistributed unless permitted
by the dataset license.
