## Response to the editor: Data Availability

We thank the editor for this recommendation. We have prepared a reproducibility
package containing the implementation code, dataset preparation and split
utilities, model training and evaluation scripts, OCR/NLP indexing utilities,
and documentation. The dataset source is identified as the Kaggle RVL-CDIP
dataset used in the study. The study-specific split files, numerical source data
underlying Figures 4–8, model artifacts, and experimental outputs will be
included in the public repository after being generated and verified from the
actual experimental run. The Data Availability section will provide the stable
repository URL and DOI once the archive is deposited.

Important: update this response only after the described materials are actually
deposited and the repository URL/DOI is available.
