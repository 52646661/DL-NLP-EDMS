# DL-NLP-EDMS reproducibility package

Example implementation for a CNN-based document image classifier with OCR/NLP-based
keyword indexing and retrieval, using the RVL-CDIP dataset.

## Important research integrity note
This is a complete runnable implementation example, not a reconstruction of your
original experiment. Your manuscript figures do not expose the exact underlying
numeric values, trained weights, or original data splits. Therefore, this package
does not fabricate the data behind Figures 4–8 or claim to reproduce those
results. Run this code on the exact Kaggle dataset version and experimental setup
used in your study, then replace manuscript results with outputs from that run.

## Dataset source
Kaggle dataset:
https://www.kaggle.com/datasets/pdavpoojan/the-rvlcdip-dataset-test

The Kaggle package may differ from the original RVL-CDIP release. After download,
inspect `data/raw/` and set the correct `--data-dir` and category mapping.
The implementation supports directory-per-class images. It does not assume that
the Kaggle subset contains 400,000 images or exactly 16 classes.

## Requirements
- Python 3.10+
- NVIDIA GPU optional; CPU execution is supported but may be slow
- Tesseract OCR executable (optional; required for OCR indexing)

Install:
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# Linux/macOS:
source .venv/bin/activate
pip install -r requirements.txt
```

## Download the dataset
Install/configure Kaggle API credentials (see Kaggle's official API documentation),
then:
```bash
kaggle datasets download -d pdavpoojan/the-rvlcdip-dataset-test -p data/raw --unzip
```
Alternatively, download through the Kaggle website and extract into `data/raw/`.

## Expected directory layout
The script searches recursively for image files and derives class labels from
parent directory names. For example:
```
data/raw/
  class_a/
    image001.png
  class_b/
    image002.jpg
```
If the dataset is already partitioned into train/test directories, review the
README and configure a split carefully to avoid data leakage. The default script
creates stratified train/validation/test indices (70/15/15) from all discovered
images. Use the exact split used in the manuscript instead.

## Run the implementation
```bash
python src/prepare_data.py --data-dir data/raw --output-dir artifacts/splits --seed 42 --train 0.70 --val 0.15 --test 0.15
python src/train.py --data-dir data/raw --split-dir artifacts/splits --output-dir artifacts/model --epochs 50 --batch-size 32 --lr 0.001
python src/evaluate.py --data-dir data/raw --split-dir artifacts/splits --model artifacts/model/best_model.keras --output-dir artifacts/results
python src/ocr_index.py --data-dir data/raw --split-dir artifacts/splits --output-dir artifacts/ocr_index --max-images 100
```

`ocr_index.py` requires Tesseract installed and available on PATH. `--max-images`
limits OCR processing for a quick example; omit it to process all images.

## Outputs
- `artifacts/splits/*.csv`: reproducible image paths, labels, and split assignments
- `artifacts/model/best_model.keras`: saved best model
- `artifacts/model/class_names.json`: class-label order
- `artifacts/results/metrics.json`: accuracy, macro precision/recall/F1
- `artifacts/results/classification_report.csv`: per-class metrics
- `artifacts/results/predictions.csv`: per-image true/predicted labels
- `artifacts/results/confusion_matrix.csv`: confusion matrix
- `artifacts/results/figure4_8_source_data.csv`: raw metric data produced by the run
- `artifacts/ocr_index/documents.jsonl`: OCR text and searchable token fields

## Figures 4–8
The provided manuscript images are bar charts, not source data. Exact numeric values
cannot be recovered reliably from screenshots. This implementation writes a
machine-readable source-data file from actual model predictions and can export
the per-image results needed to generate plots. Do not submit estimated bar
heights as experimental source data. If Figures 4–8 compare several methods or
document-count settings, implement/run those baseline methods and export their
actual outputs before depositing the final figure source data.

## Reproducibility checklist
- Record dataset source, version/download date, class list, and image counts.
- Preserve split CSVs and random seed.
- Record package versions, hardware, training command, and training logs.
- Save model weights and scripts.
- Regenerate all manuscript plots from CSV files.
- Check licensing/redistribution terms before including dataset images in the
  public GitHub/Zenodo archive. Do not bundle Kaggle dataset images unless
  redistribution is permitted.

## GitHub and Zenodo
1. Unzip this archive and create a GitHub repository.
2. Commit source code, README, requirements, and license (check licenses first).
3. Do not commit downloaded dataset images, model checkpoints, credentials, or
   private files.
4. Enable GitHub- Zenodo integration or upload a release to Zenodo.
5. Archive a release on Zenodo and obtain the DOI.
6. Replace the repository citation in the manuscript Data Availability section with
   the actual GitHub URL and Zenodo DOI after publication of the archive.
